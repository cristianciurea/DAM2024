package ro.ase.semdam_1088;

import java.util.List;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

@Dao
public interface TelefoaneDAO {

    @Insert
    void insert(Telefon telefon);

    @Insert
    void insert(List<Telefon> telefonList);

    @Query("select * from telefoane")
    List<Telefon> getAll();

    @Delete
    void delete(Telefon telefon);

    @Update
    void update(Telefon telefon);

    @Query("delete from telefoane")
    void deleteAll();
}
