package ro.ase.semdam_1088;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;

@Database(entities = {Telefon.class}, version = 1, exportSchema = false)
@TypeConverters({DateConverter.class})
public abstract class TelefoaneDB extends RoomDatabase {

    public static final String DB_NAME = "telefoane.db";

    private static TelefoaneDB instanta;

    public static TelefoaneDB getInstanta(Context context)
    {
        if(instanta==null)
            instanta = Room.databaseBuilder(context,
                    TelefoaneDB.class, DB_NAME)
                    .allowMainThreadQueries()
                    .fallbackToDestructiveMigration()
                    .build();
        return instanta;
    }

    public abstract TelefoaneDAO getTelefoaneDao();
}
