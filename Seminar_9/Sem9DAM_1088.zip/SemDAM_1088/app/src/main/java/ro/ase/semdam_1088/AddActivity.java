package ro.ase.semdam_1088;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class AddActivity extends AppCompatActivity {

    public static final String ADD_TELEFON = "addTelefon";

    private FirebaseDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        database = FirebaseDatabase.getInstance();

        Intent intent = getIntent();

        String[] culori = {"NEGRU", "ALB", "GRI", "ALBASTRU"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                androidx.appcompat.R.layout.support_simple_spinner_dropdown_item,
                culori);

        Spinner spinnerCulori = findViewById(R.id.spinnerCulori);
        spinnerCulori.setAdapter(adapter);

        EditText etProducator = findViewById(R.id.editTextProducator);
        EditText etDataAchizitie = findViewById(R.id.editTextDate);
        EditText etPret = findViewById(R.id.editTextPret);
        RadioGroup radioGroup = findViewById(R.id.radioGroup);

        if(intent.hasExtra(MainActivity.EDIT_TELEFON))
        {
            Telefon telefon = (Telefon) intent.getSerializableExtra(MainActivity.EDIT_TELEFON);

            etProducator.setText(telefon.getProducator());
            etDataAchizitie.setText(new SimpleDateFormat("MM/dd/yyyy",
                    Locale.US).format(telefon.getDataAchizitiei()));
            etPret.setText(telefon.getPret()+"");
            ArrayAdapter<String> adapter1 = (ArrayAdapter<String>) spinnerCulori.getAdapter();
            for(int i=0;i<adapter1.getCount();i++)
                if(adapter1.getItem(i).equals(telefon.getCuloare()))
                {
                    spinnerCulori.setSelection(i);
                    break;
                }
            if(telefon.getSpatiuStocare().equals("128GB"))
                radioGroup.check(R.id.radioButton128);
            else
            if(telefon.getSpatiuStocare().equals("256GB"))
                radioGroup.check(R.id.radioButton256);
            else
            if(telefon.getSpatiuStocare().equals("512GB"))
                radioGroup.check(R.id.radioButton512);
        }

        Button btnAdauga = findViewById(R.id.btnAdauga);
        btnAdauga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(etProducator.getText().toString().isEmpty())
                    etProducator.setError("Introduceti producatorul!");
                else
                    if(etDataAchizitie.getText().toString().isEmpty())
                        etDataAchizitie.setError("Introduceti data!");
                    else
                        if(etPret.getText().toString().isEmpty())
                            etPret.setError("Introduceti pretul!");
                        else {
                            SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy",
                                    Locale.US);
                            try {
                                sdf.parse(etDataAchizitie.getText().toString());
                                Date dataAchizitie = new Date(etDataAchizitie.getText().toString());

                                String producator = etProducator.getText().toString();

                                float pret = Float.parseFloat(etPret.getText().toString());

                                String culoare = spinnerCulori.getSelectedItem().toString();

                                RadioButton radioButton = findViewById(radioGroup.getCheckedRadioButtonId());
                                String spatiuStocare = radioButton.getText().toString();

                                Telefon telefon = new Telefon(producator, dataAchizitie, pret, culoare, spatiuStocare);
                                //Toast.makeText(getApplicationContext(), telefon.toString(), Toast.LENGTH_LONG).show();

                                scrieInFirebase(telefon);

                                intent.putExtra(ADD_TELEFON, telefon);
                                setResult(RESULT_OK, intent);
                                finish();

                            } catch (ParseException e) {
                                throw new RuntimeException(e);
                            }
                            catch (Exception ex)
                            {
                                Log.e("AddActivity", "Erori introducere date!");
                                Toast.makeText(getApplicationContext(),
                                        "Erori introducere date!", Toast.LENGTH_LONG).show();
                            }
                        }
            }
        });
    }

    private void scrieInFirebase(Telefon telefon)
    {
        DatabaseReference myRef = database.getReference("semdam-1088-default-rtdb");
        myRef.keepSynced(true);

        myRef.child("semdam-1088-default-rtdb").
                addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                telefon.setUid(myRef.child("semdam-1088-default-rtdb").push().getKey());

                myRef.child("semdam-1088-default-rtdb").
                        child(telefon.getUid()).setValue(telefon);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }
}