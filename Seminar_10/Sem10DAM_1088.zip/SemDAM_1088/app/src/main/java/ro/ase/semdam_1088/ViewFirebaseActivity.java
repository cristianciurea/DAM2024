package ro.ase.semdam_1088;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class ViewFirebaseActivity extends Activity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ListView listView = new ListView(this);
        List<Telefon> telefonList = new ArrayList<>();

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("semdam-1088-default-rtdb");
        myRef.keepSynced(true);

        ValueEventListener listener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists())
                {
                    telefonList.clear();
                    for(DataSnapshot dn: snapshot.getChildren())
                    {
                        Telefon telefon = dn.getValue(Telefon.class);
                        telefonList.add(telefon);
                    }
                }
                ArrayAdapter<Telefon> adapter = new ArrayAdapter<>(getApplicationContext(),
                        android.R.layout.simple_list_item_1,
                        telefonList);
                listView.setAdapter(adapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        };
        myRef.child("semdam-1088-default-rtdb").addValueEventListener(listener);

        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int position, long id) {

                Telefon telefon = telefonList.get(position);
                telefonList.remove(telefon);

                myRef.child("semdam-1088-default-rtdb").child(telefon.getUid()).removeValue();

                ArrayAdapter<Telefon> adapter = new ArrayAdapter<>(getApplicationContext(),
                        android.R.layout.simple_list_item_1,
                        telefonList);
                listView.setAdapter(adapter);

                return true;
            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {

                Telefon telefon = telefonList.get(position);

                HashMap map = new HashMap();
                map.put("producator", "APPLE");
                map.put("pret", 1000);

                myRef.child("semdam-1088-default-rtdb").child(telefon.getUid()).updateChildren(map);

                ArrayAdapter<Telefon> adapter = new ArrayAdapter<>(getApplicationContext(),
                        android.R.layout.simple_list_item_1,
                        telefonList);
                listView.setAdapter(adapter);
            }
        });

        HorizontalScrollView sv = new HorizontalScrollView(this);
        LinearLayout ll = new LinearLayout(this);
        ll.setOrientation(LinearLayout.VERTICAL);

        TextView tv = new TextView(this);
        tv.setText("Lista telefoane din Firebase\n");

        ll.addView(tv);
        ll.addView(listView);
        sv.addView(ll);

        setContentView(sv);
    }
}
