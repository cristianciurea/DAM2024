package ro.ase.semdam_1088;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import androidx.appcompat.app.AppCompatActivity;

public class BNRActivity extends AppCompatActivity {

    List<CursValutar> listaCursuri = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //EdgeToEdge.enable(this);
        setContentView(R.layout.activity_bnr);
       /* ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });*/

        TextView tvData = findViewById(R.id.tvDataCurs);
        EditText etEUR = findViewById(R.id.editTextEUR);
        EditText etUSD = findViewById(R.id.editTextUSD);
        EditText etGBP = findViewById(R.id.editTextGBP);
        EditText etXAU = findViewById(R.id.editTextXAU);

        Button btn1 = new Button(this);
        Button btn2 = findViewById(R.id.btnAfisare);
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Network network = new Network(){
                    @Override
                    protected void onPostExecute(InputStream inputStream) {
                        /*Toast.makeText(getApplicationContext(),
                                Network.rezultat,
                                Toast.LENGTH_LONG).show();*/
                        tvData.setText(cv.getDataCurs());
                        etEUR.setText(cv.getCursEUR());
                        etUSD.setText(cv.getCursUSD());
                        etGBP.setText(cv.getCursGBP());
                        etXAU.setText(cv.getCursXAU());
                    }
                };
                try {
                    network.execute(new URL("https://bnr.ro/nbrfxrates.xml"));
                } catch (MalformedURLException e) {
                    throw new RuntimeException(e);
                }


                /*etEUR.setText("4.982");
                etUSD.setText("4.556");
                etGBP.setText("6.543");
                etXAU.setText("323.456");

                Toast.makeText(getApplicationContext(),
                        "Am afisat cursul valutar!",
                        Toast.LENGTH_LONG).show();

                CursValutar cursValutar = new CursValutar("12/11/2024",
                        etEUR.getText().toString(),
                        etUSD.getText().toString(),
                        etGBP.getText().toString(),
                        etXAU.getText().toString());
                listaCursuri.add(cursValutar);*/
            }
        });

        Button btnSalvare = findViewById(R.id.btnSalvare);
        btnSalvare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                /*Intent intent = new Intent(getApplicationContext(), AfisareBNRActivity.class);
                //intent.putExtra("curs", cursValutar);
                intent.putExtra("listaCursuri", (ArrayList)listaCursuri);
                startActivity(intent);*/
                CursValutar cursValutar = new CursValutar(tvData.getText().toString(),
                        etEUR.getText().toString(),
                        etUSD.getText().toString(),
                        etGBP.getText().toString(),
                        etXAU.getText().toString());

                try {
                    scrieFisier("fisier.dat", cursValutar);
                    cursValutar = null;
                    cursValutar = citesteFisier("fisier.dat");
                    Toast.makeText(getApplicationContext(),
                            cursValutar.toString(), Toast.LENGTH_LONG).show();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        });

        Log.e("lifecycle", "Apel metoda onCreate()");
    }

    private void scrieFisier(String numeFisier, CursValutar cv) throws IOException {
        FileOutputStream fileOutputStream = openFileOutput(numeFisier, Activity.MODE_PRIVATE);
        DataOutputStream dos = new DataOutputStream(fileOutputStream);
        dos.writeUTF(cv.getDataCurs());
        dos.writeUTF(cv.getCursEUR());
        dos.writeUTF(cv.getCursUSD());
        dos.writeUTF(cv.getCursGBP());
        dos.writeUTF(cv.getCursXAU());
        dos.flush();
        fileOutputStream.close();
    }

    private CursValutar citesteFisier(String numeFisier) throws IOException
    {
        FileInputStream fileInputStream = openFileInput(numeFisier);
        DataInputStream dis = new DataInputStream(fileInputStream);
        String data = dis.readUTF();
        String euro = dis.readUTF();
        String usd = dis.readUTF();
        String gbp = dis.readUTF();
        String xau = dis.readUTF();
        CursValutar cv = new CursValutar(data, euro, usd, gbp, xau);
        fileInputStream.close();
        return cv;
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.e("lifecycle", "Apel metoda onStart()");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.e("lifecycle", "Apel metoda onResume()");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.e("lifecycle", "Apel metoda onPause()");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.e("lifecycle", "Apel metoda onStop()");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.e("lifecycle", "Apel metoda onRestart()");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.e("lifecycle", "Apel metoda onDestroy()");
    }
}