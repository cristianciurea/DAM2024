package ro.ase.semdam_1088;

import java.io.Serializable;
import java.util.Date;

public class Telefon implements Serializable {

    private String producator;
    private Date dataAchizitiei;
    private float pret;
    private String culoare;//NEGRU, ALB, GRI, ALBASTRU
    private String spatiuStocare; //128GB, 256GB, 512GB

    public Telefon(){}

    public Telefon(String producator, Date dataAchizitiei, float pret, String culoare, String spatiuStocare) {
        this.producator = producator;
        this.dataAchizitiei = dataAchizitiei;
        this.pret = pret;
        this.culoare = culoare;
        this.spatiuStocare = spatiuStocare;
    }

    public String getProducator() {
        return producator;
    }

    public void setProducator(String producator) {
        this.producator = producator;
    }

    public Date getDataAchizitiei() {
        return dataAchizitiei;
    }

    public void setDataAchizitiei(Date dataAchizitiei) {
        this.dataAchizitiei = dataAchizitiei;
    }

    public float getPret() {
        return pret;
    }

    public void setPret(float pret) {
        this.pret = pret;
    }

    public String getCuloare() {
        return culoare;
    }

    public void setCuloare(String culoare) {
        this.culoare = culoare;
    }

    public String getSpatiuStocare() {
        return spatiuStocare;
    }

    public void setSpatiuStocare(String spatiuStocare) {
        this.spatiuStocare = spatiuStocare;
    }

    @Override
    public String toString() {
        return "Telefon{" +
                "producator='" + producator + '\'' +
                ", dataAchizitiei=" + dataAchizitiei +
                ", pret=" + pret +
                ", culoare='" + culoare + '\'' +
                ", spatiuStocare='" + spatiuStocare + '\'' +
                '}';
    }
}
