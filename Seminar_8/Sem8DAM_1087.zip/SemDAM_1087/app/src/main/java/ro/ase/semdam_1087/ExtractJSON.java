package ro.ase.semdam_1087;

import android.os.AsyncTask;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

public class ExtractJSON extends AsyncTask<URL, Void, String> {

    public List<Masina> masinaListJSON = new ArrayList<>();

    @Override
    protected String doInBackground(URL... urls) {

        HttpURLConnection conexiune = null;
        try {
            conexiune = (HttpURLConnection) urls[0].openConnection();
            conexiune.setRequestMethod("GET");
            InputStream ist = conexiune.getInputStream();

            //scenariul 2 - conversie InputStream in String
            InputStreamReader isr = new InputStreamReader(ist);
            BufferedReader br =  new BufferedReader(isr);
            String linie = null;
            String rezultat = "";
            while ((linie = br.readLine())!=null)
                rezultat+=linie;

            return rezultat;

        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }

    //https://pastebin.com/raw/L84K1DxZ

}
