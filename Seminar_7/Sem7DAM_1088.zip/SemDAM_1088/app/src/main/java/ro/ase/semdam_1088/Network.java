package ro.ase.semdam_1088;

import android.os.AsyncTask;

import java.io.InputStream;
import java.net.URL;

public class Network extends AsyncTask<URL, Void, InputStream> {
    
    @Override
    protected InputStream doInBackground(URL... urls) {
        return null;
    }
}
